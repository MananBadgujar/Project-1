/**
 * 
 */
/**
 * @author manan
 *
 */
module Student_Management_System_Project {
	requires java.sql;
}